import reset

l = open('parameter.txt','r')
out = open('outputme.txt', 'w')
reset.reset_function(out)

iterator = 0
pattern_count = 0
result_address = 0
pattern_address = 0
result_register = 0

# fixes the parameter used for the program
print "............parameters............."
firstPass = True
for line in l:
	if "=" in line:
		try:
			#print "............parameters............."
		 	check = line.split("=")
			if (check[0] == 'iterator'):
				iterator = check[1].rstrip()
			elif (check[0] == 'pattern_count'):
				pattern_count = check[1].rstrip()
			elif (check[0] == 'result_address'):
				result_address = check[1].rstrip()
			elif (check[0] == 'pattern_address'):
				pattern_address = check[1].rstrip()
			elif (check[0] == 'result_register'):
				result_register = check[1].rstrip()
		except IndexError:
			firstPass = False

print 'iterator =', iterator
print 'pattern_count =', pattern_count
print 'store_result_address =', result_address
print 'test_pattern_address =', pattern_address
print 'result_register =', result_register
print "...................................."

def ProgramGenerator1(instruct):
	instr = "operation_" + instruct + ": " + "\n" + "\t" \
	 +"jal load_patterns" + "\n" + "\t" + instruct +" $"+result_register+", $2, $3" + "\n" \
	+"\t" + "sw $"+result_register+", 0($"+result_address+")"+ "\n" + "\t"+ "jal increment_offset" + "\n" + "\t" + \
	"bne $"+iterator+", $"+pattern_count+", operation_"  + instruct + "\n"
	return instr;

def ProgramGenerator2(instruct):
	instr = "operation_" + instruct + ": " + "\n" + "\t"  \
	+ "jal load_patterns" + "\n" + "\t" + instruct +" $2, $3" \
	+"\n" + "\t" + "mflo $" +result_register+ "\n" + "\t" + "sw $"+result_register+", 0($"+result_address+")"\
	+"\n" + "\t"+ "jal increment_offset" + "\n" + "\t" \
	+"bne $"+iterator+", $"+pattern_count+", operation_"  + instruct + "\n"
	return instr;

def ProgramGenerator2_a(instruct):
	instr = "operation_" + instruct + ": " + "\n" + "\t"  \
	+ "jal load_patterns" + "\n" + "\t" + instruct +" $2, $3" \
	+"\n" + "\t" + "mfhi $" +result_register+ "\n" + "\t" + "sw $"+result_register+", 0($"+result_address+")"\
	+"\n" + "\t"+ "jal increment_offset" + "\n" + "\t" \
	+"bne $"+iterator+", $"+pattern_count+", operation_"  + instruct + "\n"
	return instr;

def ProgramGenerator3(instruct):
    if (instruct == 'mthi'):
        subInstruct = "mfhi"
    elif (instruct == "mtlo"):
        subInstruct= "mtlo"
    instr = "operation_" + instruct + ": " + "\n" + "\t" \
	+ "jal load_patterns" + "\n" + "\t" + instruct +" $2"\
	+ "\n" + "\t" + subInstruct +" $"+result_register+ "\n" + "\t" \
	+ "sw $"+result_register+", 0($"+result_address+")" + "\n" + "\t" + "jal increment_offset" + "\n" \
	+ "\t" + "bne $"+iterator+", $"+pattern_count+", operation_"  + instruct + "\n"

    return instr;

f = open('parameter.txt','r')
lines = []
firstPass = True

for line in f:
	if "=" not in line:
		try:
   	 	 catergory = line[0:2]
   	 	 #print catergory
   	 	 line = line.rstrip()
   	 	 instru = line[2:]
   	 	 instr = str.strip(instru)
   	 	 if (catergory == 'a_'):
   	 	 	lines.append(ProgramGenerator1(instr))
   	 	 elif (catergory == 'b_'):
   	 	 	lines.append(ProgramGenerator2(instr))
   	 	 	lines.append(ProgramGenerator2_a(instr))
   	 	 elif (catergory == 'c_'):
   	 	 	lines.append(ProgramGenerator3(instr))
   	 	 else:
   	 	 	nothing = ''
		except IndexError:
			firstPass = False
	else:
		do="nothing"


f.close()
l.close()

for line in lines:
	if (line == lines[0]):
		print 'bingo!!'
		out.write(str(line) + "\n")
	else:
		out.write('jal reset_offsets \n')
		out.write(str(line) + "\n")

out.close()
