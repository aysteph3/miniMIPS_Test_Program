
def reset_function(file):
    file.write(" ;CODE MEMORY: (0x00000000-0x0000FFFF) \n")
    file.write(" ;DATA MEMORY: (0x00010000-0x0001FFFF) \n\n")
    file.write(" org 0000 \n\n")
    file.write(" _reset: \n\n\n")
    for x in range(31):
        file.write(" xor $%d, $%d, $%d\n" % (x, x, x))
    file.write("\n\n")
